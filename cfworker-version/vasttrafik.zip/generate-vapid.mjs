#!/usr/bin/env node
/**
 * Generates VAPID key pair for Web Push notifications.
 * Run once: node scripts/generate-vapid.mjs
 * Copy the output into wrangler.toml / wrangler secrets.
 */

function base64UrlEncode(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  bytes.forEach(b => binary += String.fromCharCode(b));
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

const keyPair = await crypto.subtle.generateKey(
  { name: 'ECDSA', namedCurve: 'P-256' },
  true,
  ['sign', 'verify']
);

const publicKeyRaw = await crypto.subtle.exportKey('raw', keyPair.publicKey);
const privateKeyPkcs8 = await crypto.subtle.exportKey('pkcs8', keyPair.privateKey);

const publicKeyB64 = base64UrlEncode(publicKeyRaw);
const privateKeyB64 = base64UrlEncode(privateKeyPkcs8);

console.log('\n✅ VAPID Keys Generated\n');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('Add to wrangler.toml [vars]:');
console.log(`VAPID_PUBLIC_KEY = "${publicKeyB64}"`);
console.log('\nRun this command for the private key (secret):');
console.log(`echo "${privateKeyB64}" | wrangler secret put VAPID_PRIVATE_KEY`);
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
