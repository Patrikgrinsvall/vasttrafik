# Västtrafik Delays — Cloudflare Serverless PWA

A fully serverless PWA hosted on **Cloudflare Pages** with:
- **Cloudflare Pages Functions** acting as a CORS proxy to the Västtrafik API
- **Cloudflare Cron Trigger** polling every 5 minutes
- **Web Push notifications** (VAPID) sent to all subscribed devices
- **Cloudflare KV** storing push subscriptions and seen delay IDs

---

## Architecture

```
Browser / Phone
  │
  ├── GET /            → Cloudflare Pages (static HTML/JS/SW)
  ├── GET /api/delays  → Pages Function → Västtrafik API (CORS proxy)
  ├── POST /api/subscribe → Pages Function → KV (save subscription)
  └── Receives Web Push notifications from Cloudflare Worker (cron)

Cloudflare Cron (every 5 min)
  └── Polls Västtrafik API
  └── Compares with seen IDs in KV
  └── Sends Web Push to all subscribed devices via KV
```

---

## Prerequisites

- A **Cloudflare account** (free tier works, but cron triggers require the **Workers Paid plan** at $5/month — the free tier allows manual triggers for testing)
- **Node.js 18+** installed on your laptop
- **Git** installed

---

## Step-by-Step Deployment

### Step 1 — Install Wrangler CLI

```bash
npm install -g wrangler
```

Verify it works:
```bash
wrangler --version
```

### Step 2 — Log in to Cloudflare

```bash
wrangler login
```

This opens a browser window. Log in and authorize Wrangler.

### Step 3 — Clone / set up the project

If you have the files from this download, navigate into the folder:
```bash
cd vasttrafik-cf
npm install
```

### Step 4 — Generate VAPID Keys

VAPID keys are required for Web Push. Generate them once:

```bash
node scripts/generate-vapid.mjs
```

You'll see output like:
```
✅ VAPID Keys Generated

Add to wrangler.toml [vars]:
VAPID_PUBLIC_KEY = "BFxyz..."

Run this command for the private key (secret):
echo "MHQCAQEEIxyz..." | wrangler secret put VAPID_PRIVATE_KEY
```

**Do these two things:**

1. Open `wrangler.toml` and add the public key to `[vars]`:
   ```toml
   [vars]
   VAPID_SUBJECT = "mailto:your@email.com"
   VAPID_PUBLIC_KEY = "BFxyz..."   # ← paste here
   ```

2. Store the private key as a secret (it will be prompted or piped):
   ```bash
   wrangler secret put VAPID_PRIVATE_KEY
   # Paste the private key value when prompted
   ```

### Step 5 — Create KV Namespace

```bash
wrangler kv:namespace create VASTTRAFIK_KV
```

The output will look like:
```
✨ Success!
Add the following to your wrangler.toml:
[[kv_namespaces]]
binding = "VASTTRAFIK_KV"
id = "abc123def456..."
```

Open `wrangler.toml` and replace `REPLACE_WITH_YOUR_KV_NAMESPACE_ID` with the real ID:
```toml
[[kv_namespaces]]
binding = "VASTTRAFIK_KV"
id = "abc123def456..."   # ← your real ID here
```

### Step 6 — Test Locally

```bash
npm run dev
```

Open `http://localhost:8788` in your browser.

> **Note:** Web Push won't work over plain `http://` locally. To test push notifications, you must deploy to Cloudflare (Step 7) since push requires HTTPS. You can still test the CORS proxy and delay fetching locally.

### Step 7 — Deploy to Cloudflare Pages

```bash
npm run deploy
```

The first time, Wrangler will ask you to either:
- Link to an existing Pages project, or
- Create a new one

Choose **Create a new project**, name it `vasttrafik-delays`.

After deploying, you'll get a URL like:
```
https://vasttrafik-delays.pages.dev
```

### Step 8 — Enable Cron Triggers (Paid plan)

If you're on the **Workers Paid plan** ($5/month), cron triggers are automatic via `wrangler.toml`.

To verify the cron is registered:
```bash
wrangler pages deployment list
```

You can also trigger the cron manually from the Cloudflare Dashboard:
1. Go to **Workers & Pages** → your project
2. Click **Settings** → **Triggers**
3. You should see the cron `*/5 * * * *` listed

To test the cron function manually:
```bash
wrangler pages deployment tail
# In another terminal, trigger via dashboard or wait for next 5-min tick
```

### Step 9 — Install as PWA on your phone

1. Open your deployed URL in **Chrome** (Android) or **Safari** (iOS)
2. Chrome: Tap the ⋮ menu → "Add to Home Screen"
   Safari: Tap the Share button → "Add to Home Screen"
3. Click **"Aktivera push-notiser"** in the app
4. Allow notifications when prompted

Your phone will now receive push notifications from Cloudflare automatically, even when the app is closed.

---

## Updating the Cron Schedule

Edit `wrangler.toml`:
```toml
[[triggers.crons]]
crons = ["*/5 * * * *"]   # every 5 minutes
# crons = ["*/1 * * * *"] # every minute
# crons = ["0 * * * *"]   # every hour
```

Then redeploy:
```bash
npm run deploy
```

---

## File Structure

```
vasttrafik-cf/
├── public/                  ← Static files served by Cloudflare Pages
│   ├── index.html           ← Main PWA UI
│   ├── sw.js                ← Service Worker (caching + push handler)
│   ├── manifest.json        ← PWA manifest (makes app installable)
│   ├── icon-192.png         ← App icon
│   └── icon-512.png         ← App icon (large)
├── functions/
│   └── api/
│       └── [[route]].js     ← Cloudflare Pages Function (API proxy + cron)
├── scripts/
│   └── generate-vapid.mjs   ← One-time VAPID key generator
├── wrangler.toml            ← Cloudflare configuration
├── package.json
└── README.md
```

---

## Troubleshooting

**"VAPID keys not configured" error in logs**
→ Make sure you've added `VAPID_PUBLIC_KEY` to `wrangler.toml` [vars] and run `wrangler secret put VAPID_PRIVATE_KEY`

**Push notifications not arriving**
→ Make sure you're on HTTPS (the deployed URL, not localhost)
→ Check that you clicked "Aktivera push-notiser" and allowed notifications
→ In Cloudflare Dashboard → Workers & Pages → your project → Logs, check for errors

**Cron not running**
→ Cron triggers require Cloudflare Workers Paid plan. On the free tier, trigger the function manually from the Dashboard for testing.

**API returns empty or error**
→ The Västtrafik API may be temporarily down or changed. Check `https://www.vasttrafik.se/api/trafficsituations/all` directly in your browser.

**"KV namespace not found" error**
→ Make sure you ran `wrangler kv:namespace create VASTTRAFIK_KV` and updated the ID in `wrangler.toml`

---

## Costs

| Resource | Free Tier | Paid |
|---|---|---|
| Pages hosting | ✅ Free | — |
| Pages Functions | ✅ 100k req/day free | $0.30/M after |
| KV storage | ✅ 100k reads/day free | $0.50/M after |
| Cron triggers | ⚠️ Requires Workers Paid ($5/mo) | Included |
| Notifications sent | Free (direct Web Push) | — |

For personal use, the only cost is **$5/month** if you want automatic cron polling. Otherwise everything else is free.
