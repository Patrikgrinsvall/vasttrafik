// sw.js – Västtrafik Delays Service Worker (Cloudflare version)
const CACHE_NAME = 'vasttrafik-cf-v1';
const STATIC = ['/', '/index.html', '/manifest.json', '/icon-192.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(STATIC).catch(() => {})));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
  ));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  // Pass through API calls to Cloudflare Functions
  if (e.request.url.includes('/api/')) return;

  e.respondWith(
    caches.match(e.request).then(cached =>
      cached || fetch(e.request).then(res => {
        if (res.ok && e.request.method === 'GET') {
          caches.open(CACHE_NAME).then(c => c.put(e.request, res.clone()));
        }
        return res;
      })
    ).catch(() => caches.match('/index.html'))
  );
});

// ─── Web Push received from Cloudflare Worker ──────────────────────
self.addEventListener('push', e => {
  let data = { title: 'Västtrafik', body: 'Ny trafikhändelse!' };
  try { data = e.data?.json() || data; } catch { data.body = e.data?.text() || data.body; }

  e.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      tag: data.tag || 'vasttrafik',
      vibrate: [200, 100, 200],
      data: { url: data.url || '/' },
      actions: [
        { action: 'open', title: '🔍 Visa detaljer' },
        { action: 'dismiss', title: '✕ Stäng' },
      ],
    })
  );
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  if (e.action === 'dismiss') return;
  const target = e.notification.data?.url || '/';
  e.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      for (const c of list) {
        if (c.url.endsWith(target) && 'focus' in c) return c.focus();
      }
      return clients.openWindow(target);
    })
  );
});
