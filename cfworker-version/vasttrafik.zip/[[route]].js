/**
 * Cloudflare Pages Function
 * Handles two routes:
 *   GET /api/delays  → Proxy to Västtrafik API (solves CORS)
 *   POST /api/notify → Called by cron to check & send Web Push notifications
 *
 * Also has a scheduled cron trigger (see wrangler.toml) that polls Västtrafik
 * and sends Web Push notifications to all subscribed devices.
 *
 * Bindings needed (set in Cloudflare dashboard or wrangler.toml):
 *   KV namespace: VASTTRAFIK_KV   (stores subscriptions + seen IDs)
 *   Env var:      VAPID_PUBLIC_KEY
 *   Env var:      VAPID_PRIVATE_KEY
 *   Env var:      VAPID_SUBJECT    (mailto:you@example.com)
 */

const API_URL = 'https://www.vasttrafik.se/api/trafficsituations/all';

// ─── Route handler (Pages Functions) ───────────────────────────────
export async function onRequest(context) {
  const { request, env } = context;
  const url = new URL(request.url);

  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  if (request.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  // GET /api/delays → proxy to Västtrafik
  if (url.pathname === '/api/delays' && request.method === 'GET') {
    try {
      const res = await fetch(API_URL, {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'VasttrafikDelaysPWA/1.0',
        },
        cf: { cacheTtl: 30, cacheEverything: true },
      });

      if (!res.ok) {
        return new Response(JSON.stringify({ error: `Upstream error: ${res.status}` }), {
          status: res.status,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const data = await res.json();
      return new Response(JSON.stringify(data), {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
          'Cache-Control': 'public, max-age=30',
        },
      });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  }

  // POST /api/subscribe → save push subscription
  if (url.pathname === '/api/subscribe' && request.method === 'POST') {
    try {
      const sub = await request.json();
      if (!sub?.endpoint) {
        return new Response(JSON.stringify({ error: 'Invalid subscription' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      // Key by endpoint hash to avoid duplicates
      const key = `sub:${await hashEndpoint(sub.endpoint)}`;
      await env.VASTTRAFIK_KV.put(key, JSON.stringify(sub), { expirationTtl: 60 * 60 * 24 * 60 }); // 60 days
      return new Response(JSON.stringify({ ok: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  }

  // DELETE /api/subscribe → remove subscription
  if (url.pathname === '/api/subscribe' && request.method === 'DELETE') {
    try {
      const { endpoint } = await request.json();
      const key = `sub:${await hashEndpoint(endpoint)}`;
      await env.VASTTRAFIK_KV.delete(key);
      return new Response(JSON.stringify({ ok: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  }

  // GET /api/vapid-public-key → return public key to client
  if (url.pathname === '/api/vapid-public-key' && request.method === 'GET') {
    return new Response(JSON.stringify({ key: env.VAPID_PUBLIC_KEY || '' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  return new Response('Not found', { status: 404 });
}

// ─── Scheduled Cron Handler ────────────────────────────────────────
export async function scheduled(event, env, ctx) {
  ctx.waitUntil(pollAndPush(env));
}

async function pollAndPush(env) {
  // 1. Fetch delays
  let data;
  try {
    const res = await fetch(API_URL, {
      headers: { 'Accept': 'application/json', 'User-Agent': 'VasttrafikDelaysPWA/1.0' },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    data = await res.json();
  } catch (e) {
    console.error('Fetch failed:', e.message);
    return;
  }

  // 2. Filter to last hour
  const items = Array.isArray(data) ? data : (data.trafficSituations || data.situations || []);
  const oneHourAgo = Date.now() - 3_600_000;
  const recent = items.filter(item => {
    const t = new Date(item.startTime || item.creationTime || item.starttime || item.created || 0).getTime();
    return t >= oneHourAgo && t <= Date.now();
  });

  if (recent.length === 0) {
    console.log('No delays in the last hour.');
    return;
  }

  // 3. Load seen IDs from KV
  const seenRaw = await env.VASTTRAFIK_KV.get('seen-ids');
  const seen = new Set(seenRaw ? JSON.parse(seenRaw) : []);

  const newItems = recent.filter(item => {
    const id = item.situationNumber || item.id || JSON.stringify(item).slice(0, 60);
    return !seen.has(id);
  });

  if (newItems.length === 0) {
    console.log('No new delays since last poll.');
    return;
  }

  // 4. Update seen IDs (keep last 500)
  newItems.forEach(item => {
    const id = item.situationNumber || item.id || JSON.stringify(item).slice(0, 60);
    seen.add(id);
  });
  const seenArr = [...seen].slice(-500);
  await env.VASTTRAFIK_KV.put('seen-ids', JSON.stringify(seenArr), { expirationTtl: 7200 });

  // 5. Build notification payload
  const title = newItems.length === 1
    ? `🚌 ${newItems[0].title || 'Ny försening'}`
    : `🚌 ${newItems.length} nya förseningar`;
  const body = newItems.length === 1
    ? (newItems[0].description || newItems[0].details || 'Se appen för detaljer.')
    : newItems.map(i => i.title || '').filter(Boolean).slice(0, 3).join(' · ');

  const payload = JSON.stringify({ title, body, tag: 'vasttrafik-delay', url: '/' });

  // 6. Load all subscriptions from KV
  const subList = await env.VASTTRAFIK_KV.list({ prefix: 'sub:' });
  console.log(`Sending to ${subList.keys.length} subscribers`);

  const pushPromises = subList.keys.map(async ({ name }) => {
    const subRaw = await env.VASTTRAFIK_KV.get(name);
    if (!subRaw) return;
    const sub = JSON.parse(subRaw);
    try {
      await sendWebPush(sub, payload, env);
    } catch (e) {
      console.error(`Push failed for ${name}:`, e.message);
      // Remove expired subscriptions (410 Gone)
      if (e.message?.includes('410') || e.message?.includes('404')) {
        await env.VASTTRAFIK_KV.delete(name);
      }
    }
  });

  await Promise.allSettled(pushPromises);
  console.log(`Notified ${subList.keys.length} devices about ${newItems.length} new delays.`);
}

// ─── Web Push (VAPID) ──────────────────────────────────────────────
async function sendWebPush(subscription, payload, env) {
  const { endpoint, keys } = subscription;
  if (!endpoint || !keys?.p256dh || !keys?.auth) throw new Error('Invalid subscription shape');

  const vapidPublic = env.VAPID_PUBLIC_KEY;
  const vapidPrivate = env.VAPID_PRIVATE_KEY;
  const vapidSubject = env.VAPID_SUBJECT || 'mailto:admin@example.com';

  if (!vapidPublic || !vapidPrivate) {
    throw new Error('VAPID keys not configured');
  }

  // Encrypt the payload using Web Push encryption (RFC 8291)
  const encrypted = await encryptPayload(payload, keys.p256dh, keys.auth);

  // Build VAPID JWT
  const vapidToken = await buildVapidJwt(endpoint, vapidSubject, vapidPrivate);
  const authHeader = `vapid t=${vapidToken},k=${vapidPublic}`;

  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Authorization': authHeader,
      'Content-Type': 'application/octet-stream',
      'Content-Encoding': 'aes128gcm',
      'TTL': '86400',
      'Urgency': 'high',
    },
    body: encrypted,
  });

  if (!res.ok && res.status !== 201) {
    throw new Error(`Push server returned ${res.status}`);
  }
}

// ─── AES-128-GCM Payload Encryption (RFC 8291) ────────────────────
async function encryptPayload(payload, p256dhBase64, authBase64) {
  const encoder = new TextEncoder();
  const plaintext = encoder.encode(payload);

  // Decode subscriber keys
  const p256dh = base64UrlDecode(p256dhBase64);
  const auth = base64UrlDecode(authBase64);

  // Generate sender key pair
  const senderKeys = await crypto.subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveKey', 'deriveBits']
  );

  const senderPublicRaw = await crypto.subtle.exportKey('raw', senderKeys.publicKey);

  // Import receiver public key
  const receiverPublic = await crypto.subtle.importKey(
    'raw', p256dh, { name: 'ECDH', namedCurve: 'P-256' }, false, []
  );

  // ECDH shared secret
  const sharedBits = await crypto.subtle.deriveBits(
    { name: 'ECDH', public: receiverPublic }, senderKeys.privateKey, 256
  );

  // Salt
  const salt = crypto.getRandomValues(new Uint8Array(16));

  // HKDF context
  const authInfo = encoder.encode('WebPush: info\0');
  const context = concat(authInfo, p256dh, new Uint8Array(senderPublicRaw));

  // PRK
  const prkKey = await crypto.subtle.importKey('raw', auth, { name: 'HKDF' }, false, ['deriveBits']);
  const prk = await crypto.subtle.deriveBits(
    { name: 'HKDF', hash: 'SHA-256', salt: new Uint8Array(sharedBits), info: context },
    prkKey, 256
  );

  // CEK
  const cekInfo = encoder.encode('Content-Encoding: aes128gcm\0');
  const prkKey2 = await crypto.subtle.importKey('raw', prk, { name: 'HKDF' }, false, ['deriveBits']);
  const cekBits = await crypto.subtle.deriveBits(
    { name: 'HKDF', hash: 'SHA-256', salt, info: cekInfo }, prkKey2, 128
  );

  // Nonce
  const nonceInfo = encoder.encode('Content-Encoding: nonce\0');
  const prkKey3 = await crypto.subtle.importKey('raw', prk, { name: 'HKDF' }, false, ['deriveBits']);
  const nonceBits = await crypto.subtle.deriveBits(
    { name: 'HKDF', hash: 'SHA-256', salt, info: nonceInfo }, prkKey3, 96
  );

  const cekKey = await crypto.subtle.importKey('raw', cekBits, { name: 'AES-GCM' }, false, ['encrypt']);

  // Pad plaintext (add delimiter byte 0x02 + padding)
  const paddedLen = plaintext.length + 1;
  const padded = new Uint8Array(paddedLen);
  padded.set(plaintext);
  padded[plaintext.length] = 0x02;

  const ciphertext = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: new Uint8Array(nonceBits) }, cekKey, padded
  );

  // aes128gcm record header: salt(16) + rs(4) + idlen(1) + keyid(65)
  const rs = new Uint8Array(4);
  new DataView(rs.buffer).setUint32(0, 4096, false);
  const senderPubArr = new Uint8Array(senderPublicRaw);
  const idlen = new Uint8Array([senderPubArr.length]);

  return concat(salt, rs, idlen, senderPubArr, new Uint8Array(ciphertext));
}

// ─── VAPID JWT ─────────────────────────────────────────────────────
async function buildVapidJwt(endpoint, subject, privateKeyBase64) {
  const url = new URL(endpoint);
  const audience = `${url.protocol}//${url.host}`;
  const expiry = Math.floor(Date.now() / 1000) + 12 * 3600;

  const header = base64UrlEncode(JSON.stringify({ typ: 'JWT', alg: 'ES256' }));
  const claims = base64UrlEncode(JSON.stringify({ aud: audience, exp: expiry, sub: subject }));
  const unsigned = `${header}.${claims}`;

  const privateKeyDer = base64UrlDecode(privateKeyBase64);
  const key = await crypto.subtle.importKey(
    'pkcs8', privateKeyDer,
    { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']
  );

  const sig = await crypto.subtle.sign(
    { name: 'ECDSA', hash: 'SHA-256' },
    key,
    new TextEncoder().encode(unsigned)
  );

  return `${unsigned}.${base64UrlEncode(new Uint8Array(sig))}`;
}

// ─── Helpers ───────────────────────────────────────────────────────
function base64UrlDecode(str) {
  const padded = str.replace(/-/g, '+').replace(/_/g, '/');
  const binary = atob(padded + '='.repeat((4 - padded.length % 4) % 4));
  return Uint8Array.from(binary, c => c.charCodeAt(0));
}

function base64UrlEncode(input) {
  const bytes = typeof input === 'string' ? new TextEncoder().encode(input) : input;
  let binary = '';
  bytes.forEach(b => binary += String.fromCharCode(b));
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function concat(...arrays) {
  const total = arrays.reduce((n, a) => n + a.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const a of arrays) { out.set(a, offset); offset += a.length; }
  return out;
}

async function hashEndpoint(endpoint) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(endpoint));
  return base64UrlEncode(new Uint8Array(buf)).slice(0, 16);
}
